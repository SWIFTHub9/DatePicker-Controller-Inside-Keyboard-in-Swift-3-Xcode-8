//
//  ViewController.swift
//  Add Date Picker Into textfield
//
//  Created by Abhishek Verma on 19/07/17.
//  Copyright © 2017 Abhishek Verma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var datepicker = UIDatePicker()

    @IBOutlet weak var Textfield1: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        createdatepicker()
    }
    
    func createdatepicker() {
        datepicker.datePickerMode = .dateAndTime
        
        let tollbar = UIToolbar()
        tollbar.sizeToFit()
        
        let donebutton = UIBarButtonItem(barButtonSystemItem: .done, target: self, action: #selector(doneac))
        tollbar.setItems([donebutton], animated: true)
        Textfield1.inputAccessoryView = tollbar
        
        Textfield1.inputView = datepicker
        
    }
    
    func doneac() {
        Textfield1.text = "\(datepicker.date)"
        self.view.endEditing(true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

